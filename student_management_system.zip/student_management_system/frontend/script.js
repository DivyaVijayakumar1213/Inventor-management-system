// ---------------------------------------------------------------
// Student Management System - Frontend logic
// Talks to the Django REST API defined in config.js (API_BASE_URL)
// ---------------------------------------------------------------

const form = document.getElementById("studentForm");
const formTitle = document.getElementById("formTitle");
const submitBtn = document.getElementById("submitBtn");
const cancelBtn = document.getElementById("cancelBtn");
const studentsBody = document.getElementById("studentsBody");
const alertBox = document.getElementById("alertBox");
const searchInput = document.getElementById("searchInput");
const orderingSelect = document.getElementById("orderingSelect");
const refreshBtn = document.getElementById("refreshBtn");
const prevPageBtn = document.getElementById("prevPageBtn");
const nextPageBtn = document.getElementById("nextPageBtn");
const pageInfo = document.getElementById("pageInfo");

const confirmModal = document.getElementById("confirmModal");
const confirmText = document.getElementById("confirmText");
const confirmYes = document.getElementById("confirmYes");
const confirmNo = document.getElementById("confirmNo");

let currentPageUrl = `${API_BASE_URL}/students/`;
let editingId = null;
let pendingDeleteId = null;
let searchDebounce = null;

// ---------------- Utility: alerts ----------------
function showAlert(message, type = "success") {
  alertBox.textContent = message;
  alertBox.className = `alert ${type}`;
  alertBox.classList.remove("hidden");
  setTimeout(() => alertBox.classList.add("hidden"), 4000);
}

function clearFieldErrors() {
  document.querySelectorAll(".error").forEach((el) => (el.textContent = ""));
}

// ---------------- Client-side validation ----------------
function validateForm(data) {
  let valid = true;
  clearFieldErrors();

  if (!data.roll_no.trim()) {
    document.getElementById("err_roll_no").textContent = "Roll number is required.";
    valid = false;
  }
  if (!data.first_name.trim()) {
    document.getElementById("err_first_name").textContent = "First name is required.";
    valid = false;
  }
  if (!data.last_name.trim()) {
    document.getElementById("err_last_name").textContent = "Last name is required.";
    valid = false;
  }
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailPattern.test(data.email)) {
    document.getElementById("err_email").textContent = "Enter a valid email address.";
    valid = false;
  }
  if (data.phone && !/^\+?\d{7,15}$/.test(data.phone)) {
    document.getElementById("err_phone").textContent = "Phone must be 7-15 digits.";
    valid = false;
  }
  if (!data.department.trim()) {
    document.getElementById("err_department").textContent = "Department is required.";
    valid = false;
  }
  return valid;
}

// ---------------- Form data helpers ----------------
function readFormData() {
  return {
    roll_no: document.getElementById("roll_no").value,
    first_name: document.getElementById("first_name").value,
    last_name: document.getElementById("last_name").value,
    email: document.getElementById("email").value,
    phone: document.getElementById("phone").value,
    department: document.getElementById("department").value,
    year: parseInt(document.getElementById("year").value, 10),
    date_of_admission: document.getElementById("date_of_admission").value || null,
    is_active: document.getElementById("is_active").checked,
  };
}

function fillForm(student) {
  document.getElementById("studentId").value = student.id;
  document.getElementById("roll_no").value = student.roll_no;
  document.getElementById("first_name").value = student.first_name;
  document.getElementById("last_name").value = student.last_name;
  document.getElementById("email").value = student.email;
  document.getElementById("phone").value = student.phone || "";
  document.getElementById("department").value = student.department;
  document.getElementById("year").value = student.year;
  document.getElementById("date_of_admission").value = student.date_of_admission || "";
  document.getElementById("is_active").checked = student.is_active;
}

function resetForm() {
  form.reset();
  document.getElementById("studentId").value = "";
  document.getElementById("is_active").checked = true;
  editingId = null;
  formTitle.textContent = "Add Student";
  submitBtn.textContent = "Add Student";
  cancelBtn.classList.add("hidden");
  clearFieldErrors();
}

// ---------------- API calls ----------------
async function apiRequest(url, options = {}) {
  const response = await fetch(url, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  let payload = null;
  try {
    payload = await response.json();
  } catch (e) {
    payload = null;
  }
  if (!response.ok) {
    const err = new Error("API request failed");
    err.status = response.status;
    err.payload = payload;
    throw err;
  }
  return payload;
}

async function fetchStudents(url = currentPageUrl) {
  studentsBody.innerHTML = `<tr><td colspan="8" class="empty-row">Loading...</td></tr>`;
  try {
    const data = await apiRequest(url);
    renderTable(data.results || data); // supports paginated or plain list
    updatePagination(data);
  } catch (err) {
    studentsBody.innerHTML = `<tr><td colspan="8" class="empty-row">
      Could not reach the backend at ${API_BASE_URL}. Is the Django server running?
    </td></tr>`;
    console.error(err);
  }
}

function updatePagination(data) {
  if (!data || typeof data !== "object" || !("next" in data)) {
    // plain list, no pagination info
    prevPageBtn.disabled = true;
    nextPageBtn.disabled = true;
    pageInfo.textContent = "";
    return;
  }
  prevPageBtn.disabled = !data.previous;
  nextPageBtn.disabled = !data.next;
  prevPageBtn.onclick = () => data.previous && fetchStudents(data.previous);
  nextPageBtn.onclick = () => data.next && fetchStudents(data.next);
  pageInfo.textContent = `${data.count} student(s) total`;
}

function renderTable(students) {
  if (!students || students.length === 0) {
    studentsBody.innerHTML = `<tr><td colspan="8" class="empty-row">No students found.</td></tr>`;
    return;
  }

  studentsBody.innerHTML = students
    .map(
      (s) => `
    <tr>
      <td>${escapeHtml(s.roll_no)}</td>
      <td>${escapeHtml(s.first_name)} ${escapeHtml(s.last_name)}</td>
      <td>${escapeHtml(s.email)}</td>
      <td>${escapeHtml(s.phone || "-")}</td>
      <td>${escapeHtml(s.department)}</td>
      <td>Year ${s.year}</td>
      <td><span class="badge ${s.is_active ? "badge-active" : "badge-inactive"}">
        ${s.is_active ? "Active" : "Inactive"}
      </span></td>
      <td class="row-actions">
        <button class="btn btn-secondary btn-sm" onclick="startEdit(${s.id})">Edit</button>
        <button class="btn btn-danger btn-sm" onclick="askDelete(${s.id}, '${escapeHtml(s.roll_no)}')">Delete</button>
      </td>
    </tr>`
    )
    .join("");
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str ?? "";
  return div.innerHTML;
}

// ---------------- Create / Update ----------------
form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const data = readFormData();
  if (!validateForm(data)) return;

  submitBtn.disabled = true;
  try {
    if (editingId) {
      await apiRequest(`${API_BASE_URL}/students/${editingId}/`, {
        method: "PUT",
        body: JSON.stringify(data),
      });
      showAlert("Student updated successfully.", "success");
    } else {
      await apiRequest(`${API_BASE_URL}/students/`, {
        method: "POST",
        body: JSON.stringify(data),
      });
      showAlert("Student added successfully.", "success");
    }
    resetForm();
    fetchStudents(`${API_BASE_URL}/students/`);
  } catch (err) {
    handleApiError(err);
  } finally {
    submitBtn.disabled = false;
  }
});

function handleApiError(err) {
  if (err.payload && typeof err.payload === "object") {
    // Map DRF field errors onto the form
    let firstMessage = null;
    Object.entries(err.payload).forEach(([field, messages]) => {
      const el = document.getElementById(`err_${field}`);
      const msg = Array.isArray(messages) ? messages.join(" ") : String(messages);
      if (el) el.textContent = msg;
      if (!firstMessage) firstMessage = `${field}: ${msg}`;
    });
    showAlert(firstMessage || "Please correct the errors and try again.", "error");
  } else {
    showAlert("Something went wrong talking to the server.", "error");
  }
  console.error(err);
}

// ---------------- Edit ----------------
window.startEdit = async function (id) {
  try {
    const student = await apiRequest(`${API_BASE_URL}/students/${id}/`);
    fillForm(student);
    editingId = id;
    formTitle.textContent = `Edit Student — ${student.roll_no}`;
    submitBtn.textContent = "Save Changes";
    cancelBtn.classList.remove("hidden");
    window.scrollTo({ top: 0, behavior: "smooth" });
  } catch (err) {
    handleApiError(err);
  }
};

cancelBtn.addEventListener("click", resetForm);

// ---------------- Delete ----------------
window.askDelete = function (id, rollNo) {
  pendingDeleteId = id;
  confirmText.textContent = `Delete student "${rollNo}"? This cannot be undone.`;
  confirmModal.classList.remove("hidden");
};

confirmNo.addEventListener("click", () => {
  pendingDeleteId = null;
  confirmModal.classList.add("hidden");
});

confirmYes.addEventListener("click", async () => {
  if (!pendingDeleteId) return;
  try {
    await apiRequest(`${API_BASE_URL}/students/${pendingDeleteId}/`, { method: "DELETE" });
    showAlert("Student deleted.", "success");
    fetchStudents(`${API_BASE_URL}/students/`);
  } catch (err) {
    handleApiError(err);
  } finally {
    pendingDeleteId = null;
    confirmModal.classList.add("hidden");
  }
});

// ---------------- Search & ordering ----------------
function buildListUrl() {
  const params = new URLSearchParams();
  if (searchInput.value.trim()) params.set("search", searchInput.value.trim());
  if (orderingSelect.value) params.set("ordering", orderingSelect.value);
  return `${API_BASE_URL}/students/?${params.toString()}`;
}

searchInput.addEventListener("input", () => {
  clearTimeout(searchDebounce);
  searchDebounce = setTimeout(() => fetchStudents(buildListUrl()), 350);
});

orderingSelect.addEventListener("change", () => fetchStudents(buildListUrl()));
refreshBtn.addEventListener("click", () => fetchStudents(buildListUrl()));

// ---------------- Init ----------------
document.addEventListener("DOMContentLoaded", () => fetchStudents());
