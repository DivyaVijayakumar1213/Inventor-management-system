import django.core.validators
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name="Student",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("roll_no", models.CharField(help_text="Unique roll number / student ID.", max_length=20, unique=True)),
                ("first_name", models.CharField(max_length=50)),
                ("last_name", models.CharField(max_length=50)),
                ("email", models.EmailField(max_length=254, unique=True)),
                (
                    "phone",
                    models.CharField(
                        blank=True,
                        max_length=15,
                        validators=[
                            django.core.validators.RegexValidator(
                                message="Enter a valid phone number (7 to 15 digits, optional leading +).",
                                regex="^\\+?\\d{7,15}$",
                            )
                        ],
                    ),
                ),
                ("department", models.CharField(max_length=100)),
                (
                    "year",
                    models.PositiveSmallIntegerField(
                        choices=[(1, "1st Year"), (2, "2nd Year"), (3, "3rd Year"), (4, "4th Year")],
                        default=1,
                    ),
                ),
                ("date_of_admission", models.DateField(blank=True, null=True)),
                ("is_active", models.BooleanField(default=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={
                "ordering": ["roll_no"],
            },
        ),
    ]
