from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase

from .models import Student


class StudentCRUDTests(APITestCase):
    """
    Covers SOP Sec. 10 test procedure: create (valid/missing/duplicate),
    read, update (valid/invalid id), delete (valid/invalid id).
    """

    def setUp(self):
        self.student = Student.objects.create(
            roll_no="CS2024001",
            first_name="Aarav",
            last_name="Sharma",
            email="aarav@example.com",
            department="Computer Science",
            year=2,
        )
        self.list_url = "/api/students/"

    def detail_url(self, pk):
        return f"/api/students/{pk}/"

    # ---- CREATE ----
    def test_create_valid_student(self):
        payload = {
            "roll_no": "CS2024002",
            "first_name": "Diya",
            "last_name": "Iyer",
            "email": "diya@example.com",
            "department": "Computer Science",
            "year": 1,
        }
        response = self.client.post(self.list_url, payload, format="json")
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(Student.objects.count(), 2)

    def test_create_missing_required_field(self):
        payload = {"first_name": "NoRollNo"}
        response = self.client.post(self.list_url, payload, format="json")
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_create_duplicate_roll_no(self):
        payload = {
            "roll_no": "CS2024001",  # duplicate
            "first_name": "Dup",
            "last_name": "Licate",
            "email": "dup@example.com",
            "department": "CS",
            "year": 1,
        }
        response = self.client.post(self.list_url, payload, format="json")
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    # ---- READ ----
    def test_list_students(self):
        response = self.client.get(self.list_url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_retrieve_student(self):
        response = self.client.get(self.detail_url(self.student.id))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["data"]["roll_no"] if "data" in response.data else response.data["roll_no"], "CS2024001")

    def test_retrieve_invalid_id(self):
        response = self.client.get(self.detail_url(999999))
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    # ---- UPDATE ----
    def test_update_valid_student(self):
        payload = {
            "roll_no": "CS2024001",
            "first_name": "Aarav",
            "last_name": "Sharma",
            "email": "aarav.new@example.com",
            "department": "Computer Science",
            "year": 3,
        }
        response = self.client.put(self.detail_url(self.student.id), payload, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.student.refresh_from_db()
        self.assertEqual(self.student.year, 3)

    def test_update_invalid_id(self):
        payload = {
            "roll_no": "X", "first_name": "X", "last_name": "X",
            "email": "x@example.com", "department": "X", "year": 1,
        }
        response = self.client.put(self.detail_url(999999), payload, format="json")
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    # ---- DELETE ----
    def test_delete_valid_student(self):
        response = self.client.delete(self.detail_url(self.student.id))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(Student.objects.count(), 0)

    def test_delete_invalid_id(self):
        response = self.client.delete(self.detail_url(999999))
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)
