from rest_framework import serializers

from .models import Student


class StudentSerializer(serializers.ModelSerializer):
    full_name = serializers.ReadOnlyField()

    class Meta:
        model = Student
        fields = [
            "id",
            "roll_no",
            "first_name",
            "last_name",
            "full_name",
            "email",
            "phone",
            "department",
            "year",
            "date_of_admission",
            "is_active",
            "created_at",
            "updated_at",
        ]
        read_only_fields = ["id", "created_at", "updated_at"]

    # ---- Server-side validation (SOP Sec. 9) ----
    def validate_roll_no(self, value):
        value = value.strip()
        if not value:
            raise serializers.ValidationError("Roll number cannot be empty.")
        return value

    def validate_first_name(self, value):
        if not value.strip():
            raise serializers.ValidationError("First name cannot be empty.")
        return value.strip()

    def validate_last_name(self, value):
        if not value.strip():
            raise serializers.ValidationError("Last name cannot be empty.")
        return value.strip()

    def validate_department(self, value):
        if not value.strip():
            raise serializers.ValidationError("Department cannot be empty.")
        return value.strip()
