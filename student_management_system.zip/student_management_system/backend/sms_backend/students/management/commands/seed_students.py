from django.core.management.base import BaseCommand

from students.models import Student


SAMPLE_STUDENTS = [
    dict(roll_no="CS2024001", first_name="Aarav", last_name="Sharma",
         email="aarav.sharma@example.com", phone="9876543210",
         department="Computer Science", year=2),
    dict(roll_no="CS2024002", first_name="Diya", last_name="Iyer",
         email="diya.iyer@example.com", phone="9876543211",
         department="Computer Science", year=3),
    dict(roll_no="EC2024010", first_name="Rohan", last_name="Verma",
         email="rohan.verma@example.com", phone="9876543212",
         department="Electronics", year=1),
    dict(roll_no="ME2024005", first_name="Sneha", last_name="Nair",
         email="sneha.nair@example.com", phone="9876543213",
         department="Mechanical", year=4),
]


class Command(BaseCommand):
    help = "Seed the database with sample student records for demo/testing."

    def handle(self, *args, **options):
        created = 0
        for data in SAMPLE_STUDENTS:
            _, was_created = Student.objects.get_or_create(
                roll_no=data["roll_no"], defaults=data
            )
            if was_created:
                created += 1
        self.stdout.write(
            self.style.SUCCESS(f"Seeded {created} new student record(s).")
        )
