from rest_framework import viewsets, filters, status
from rest_framework.response import Response

from .models import Student
from .serializers import StudentSerializer


class StudentViewSet(viewsets.ModelViewSet):
    """
    Full CRUD REST API for the Student entity (SOP Sec. 7.6):

        GET    /api/students/           -> list (supports ?search= & ?ordering=)
        POST   /api/students/           -> create
        GET    /api/students/{id}/      -> retrieve
        PUT    /api/students/{id}/      -> full update
        PATCH  /api/students/{id}/      -> partial update
        DELETE /api/students/{id}/      -> delete
    """

    queryset = Student.objects.all()
    serializer_class = StudentSerializer
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ["roll_no", "first_name", "last_name", "email", "department"]
    ordering_fields = ["roll_no", "first_name", "last_name", "year", "created_at"]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        self.perform_create(serializer)
        return Response(
            {"message": "Student created successfully.", "data": serializer.data},
            status=status.HTTP_201_CREATED,
        )

    def update(self, request, *args, **kwargs):
        partial = kwargs.pop("partial", False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        self.perform_update(serializer)
        return Response(
            {"message": "Student updated successfully.", "data": serializer.data}
        )

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        roll_no = instance.roll_no
        self.perform_destroy(instance)
        return Response(
            {"message": f"Student '{roll_no}' deleted successfully."},
            status=status.HTTP_200_OK,
        )
